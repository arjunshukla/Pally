//
//  MessageVC.h
//  TestApp
//
//  Created by Karanbeer Singh on 12/14/14.
//  Copyright (c) 2014 Karanbeer Singh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MessageVC : UIViewController
{
    
}
@property (nonatomic, strong) UIImage *myimage;
@property (nonatomic, strong) NSString *useidfrnd;
@property (nonatomic, strong) NSString *usefrndname;

@property (nonatomic, strong) NSArray *dictData;
@end
