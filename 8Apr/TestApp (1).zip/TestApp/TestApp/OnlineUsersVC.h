//
//  OnlineUsersVC.h
//  TestApp
//
//  Created by Karanbeer Singh on 12/29/14.
//  Copyright (c) 2014 Karanbeer Singh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OnlineUsersVC : UIViewController
@property(nonatomic,strong)NSArray *main_arry;

@end
