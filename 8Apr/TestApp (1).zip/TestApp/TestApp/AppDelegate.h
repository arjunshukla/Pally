//
//  AppDelegate.h
//  TestApp
//
//  Created by Karanbeer Singh on 11/18/14.
//  Copyright (c) 2014 Karanbeer Singh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "REFrostedViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate,REFrostedViewControllerDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

