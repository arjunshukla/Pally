//
//  SignUPVC.h
//  TestApp
//
//  Created by Karanbeer Singh on 11/18/14.
//  Copyright (c) 2014 Karanbeer Singh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SignUPVC : UIViewController

@end
