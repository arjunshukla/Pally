//
//  ForgetPasswrdVC.h
//  TestApp
//
//  Created by Karanbeer Singh on 11/19/14.
//  Copyright (c) 2014 Karanbeer Singh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ForgetPasswrdVC : UIViewController

@end
