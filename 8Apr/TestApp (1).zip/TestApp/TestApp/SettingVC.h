//
//  SettingVC.h
//  TestApp
//
//  Created by Karanbeer Singh on 11/22/14.
//  Copyright (c) 2014 Karanbeer Singh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingVC : UIViewController

@end
