//
//  NotificationListViewController.h
//  TestApp
//
//  Created by Karanbeer Singh on 1/18/15.
//  Copyright (c) 2015 Karanbeer Singh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NotificationListViewController : UIViewController

@end
